<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Inventario</title>
    <link rel="stylesheet" href="<?= esc(base_url('css/inventario.css'), 'attr') ?>">
</head>
<body class="pagina-login">
    <main class="tarjeta login">
        <h1>Iniciar sesión</h1>

        <?php if ($exito = session()->getFlashdata('exito')): ?>
            <p class="alerta alerta-exito" role="status"><?= esc($exito) ?></p>
        <?php endif; ?>
        <?php if ($error = session()->getFlashdata('error')): ?>
            <p class="alerta alerta-error" role="alert"><?= esc($error) ?></p>
        <?php endif; ?>
        <?php if ($info = session()->getFlashdata('info')): ?>
            <p class="alerta alerta-info" role="status"><?= esc($info) ?></p>
        <?php endif; ?>

        <form method="post" action="<?= esc(site_url('login'), 'attr') ?>">
            <?= csrf_field() ?>
            <div class="campo">
                <label for="usuario">Usuario</label>
                <input id="usuario" name="usuario" type="text" autocomplete="username"
                       maxlength="50" required autofocus>
            </div>
            <div class="campo">
                <label for="password">Contraseña</label>
                <input id="password" name="password" type="password" autocomplete="current-password"
                       maxlength="72" required>
            </div>
            <button class="boton boton-principal boton-login" type="submit">Ingresar</button>
        </form>
        <p class="enlace-cuenta">¿No tienes cuenta? <a href="<?= esc(site_url('registro'), 'attr') ?>">Registrar cuenta</a></p>
    </main>
</body>
</html>
