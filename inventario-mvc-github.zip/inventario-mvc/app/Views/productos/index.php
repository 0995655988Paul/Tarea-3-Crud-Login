<?php
$exito = session()->getFlashdata('exito');
$error = session()->getFlashdata('error');
$info = session()->getFlashdata('info');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Productos | Inventario</title>
    <link rel="stylesheet" href="<?= esc(base_url('css/inventario.css'), 'attr') ?>">
</head>
<body>
    <?= view('partials/cabecera', ['usuario' => $usuario]) ?>

    <main class="contenedor">
        <?php if ($exito): ?>
            <p class="alerta alerta-exito" role="status"><?= esc($exito) ?></p>
        <?php endif; ?>
        <?php if ($info): ?>
            <p class="alerta alerta-info" role="status"><?= esc($info) ?></p>
        <?php endif; ?>
        <?php if ($error): ?>
            <p class="alerta alerta-error" role="alert"><?= esc($error) ?></p>
        <?php endif; ?>

        <section class="tarjeta" aria-labelledby="titulo-productos">
            <div class="encabezado">
                <h1 id="titulo-productos">Productos</h1>
                <a class="boton boton-principal" href="<?= esc(site_url('productos/nuevo'), 'attr') ?>">Agregar producto</a>
            </div>

            <div class="tabla-contenedor">
                <table>
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Nombre</th>
                            <th scope="col" class="numero">Precio</th>
                            <th scope="col" class="numero">Stock</th>
                            <th scope="col">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productos as $producto): ?>
                            <tr>
                                <td><?= (int) $producto['id'] ?></td>
                                <td><?= esc($producto['nombre']) ?></td>
                                <td class="numero">$ <?= number_format((float) $producto['precio'], 2, '.', ',') ?></td>
                                <td class="numero"><?= (int) $producto['stock'] ?></td>
                                <td>
                                    <div class="acciones">
                                        <a class="boton" href="<?= esc(site_url('productos/' . (int) $producto['id'] . '/editar'), 'attr') ?>">Editar</a>
                                        <form method="post" action="<?= esc(site_url('productos/' . (int) $producto['id'] . '/eliminar'), 'attr') ?>"
                                              onsubmit="return confirm('¿Eliminar este producto?');">
                                            <?= csrf_field() ?>
                                            <button class="boton boton-peligro" type="submit">Eliminar</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if ($productos === []): ?>
                            <tr><td class="sin-productos" colspan="5">No hay productos registrados.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</body>
</html>
