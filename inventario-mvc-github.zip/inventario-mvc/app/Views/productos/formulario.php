<?php
$esEdicion = $producto !== null;
$titulo = $esEdicion ? 'Editar producto' : 'Nuevo producto';
$accion = $esEdicion
    ? 'productos/' . (int) $producto['id'] . '/actualizar'
    : 'productos/guardar';
$error = session()->getFlashdata('error');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($titulo) ?> | Inventario</title>
    <link rel="stylesheet" href="<?= esc(base_url('css/inventario.css'), 'attr') ?>">
</head>
<body>
    <?= view('partials/cabecera', ['usuario' => $usuario]) ?>

    <main class="contenedor formulario-pagina">
        <section class="tarjeta" aria-labelledby="titulo-formulario">
            <h1 id="titulo-formulario"><?= esc($titulo) ?></h1>

            <?php if ($error): ?>
                <p class="alerta alerta-error" role="alert"><?= esc($error) ?></p>
            <?php endif; ?>
            <?php if ($errores !== []): ?>
                <div class="alerta alerta-error" role="alert">
                    <ul>
                        <?php foreach ($errores as $mensaje): ?>
                            <li><?= esc($mensaje) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" action="<?= esc(site_url($accion), 'attr') ?>">
                <?= csrf_field() ?>
                <div class="campo">
                    <label for="nombre">Nombre</label>
                    <input id="nombre" name="nombre" type="text" required minlength="1" maxlength="100"
                           value="<?= esc((string) ($datos['nombre'] ?? ''), 'attr') ?>"
                           aria-invalid="<?= isset($errores['nombre']) ? 'true' : 'false' ?>" autofocus>
                </div>
                <div class="campo">
                    <label for="precio">Precio</label>
                    <input id="precio" name="precio" type="number" required min="0" max="99999999.99"
                           step="0.01" inputmode="decimal"
                           value="<?= esc((string) ($datos['precio'] ?? ''), 'attr') ?>"
                           aria-invalid="<?= isset($errores['precio']) ? 'true' : 'false' ?>">
                </div>
                <div class="campo">
                    <label for="stock">Stock</label>
                    <input id="stock" name="stock" type="number" required min="0" max="999999999"
                           step="1" inputmode="numeric"
                           value="<?= esc((string) ($datos['stock'] ?? '0'), 'attr') ?>"
                           aria-invalid="<?= isset($errores['stock']) ? 'true' : 'false' ?>">
                </div>
                <div class="acciones">
                    <button class="boton boton-principal" type="submit">Guardar</button>
                    <a class="boton" href="<?= esc(site_url('productos'), 'attr') ?>">Cancelar</a>
                </div>
            </form>
        </section>
    </main>
</body>
</html>
