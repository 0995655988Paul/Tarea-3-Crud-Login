<header class="barra-superior">
    <a class="titulo-app" href="<?= esc(site_url('productos'), 'attr') ?>">Inventario</a>
    <div class="sesion">
        <span>Usuario: <?= esc($usuario) ?></span>
        <form method="post" action="<?= esc(site_url('salir'), 'attr') ?>">
            <?= csrf_field() ?>
            <button class="boton" type="submit">Cerrar sesión</button>
        </form>
    </div>
</header>
